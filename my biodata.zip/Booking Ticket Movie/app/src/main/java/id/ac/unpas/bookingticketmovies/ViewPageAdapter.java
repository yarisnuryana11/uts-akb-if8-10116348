package id.ac.unpas.bookingticketmovies;
//19/05/2019
//10116348
//yarisnuryana
//akbif08
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import id.ac.unpas.bookingticketmovies.Fragment.Fragment1;
import id.ac.unpas.bookingticketmovies.Fragment.Fragment2;

public class ViewPageAdapter extends FragmentPagerAdapter {

    public ViewPageAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            return new Fragment1();
        } else return new Fragment2();
    }

    @Override
    public int getCount() {
        return 2;
    }
}
