package id.ac.unpas.bookingticketmovies;
//19/05/2019
//10116348
//yarisnuryana
//akbif08

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import id.ac.unpas.bookingticketmovies.R;

public class TambahTeman extends AppCompatActivity {
    TextView txnim, txnama, txkelas, txtelepon, txemail, txsosmed;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_teman);
        txnim = (TextView) findViewById(R.id.TFnim);
        txnama = (TextView) findViewById(R.id.TFnama);
        txkelas = (TextView) findViewById(R.id.TFkelas);
        txtelepon = (TextView) findViewById(R.id.TFtelepon);
        txemail = (TextView) findViewById(R.id.TFemail);
        txsosmed = (TextView) findViewById(R.id.TFsosmed);
        btn = (Button) findViewById(R.id.Btambah);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nim = txnim.getText().toString().trim();
                String nama = txnama.getText().toString().trim();
                String kelas = txkelas.getText().toString().trim();
                String telepon = txtelepon.getText().toString().trim();
                String email = txemail.getText().toString().trim();
                String sosmed = txsosmed.getText().toString().trim();
                Bundle bundle = new Bundle();
                Intent intent = new Intent(TambahTeman.this, DaftarTemanActivity.class);
                bundle.putString("nama", nama);
                bundle.putString("nim", nim);
                bundle.putString("kelas", kelas);
                bundle.putString("telepon", telepon);
                bundle.putString("email", email);
                bundle.putString("sosmed", sosmed);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}
