package id.ac.unpas.bookingticketmovies;
//19/05/2019
//10116348
//yarisnuryana
//akbif08

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Helper {
    Teman teman;
    ArrayList<Teman> arrTeman;

    public Helper() {
        arrTeman = new ArrayList<Teman>();
    }

    public void simpanTeman(String nim, String nama, String kelas, String tlp, String email, String sosmed){
        arrTeman.add(new Teman(nim, nama, kelas, tlp, email, sosmed));
    }

    public List<String> tampilTeman(){
        List<String> vTampil = new ArrayList<String>();
        for (Teman teman : arrTeman){
            String tampil = teman.getNim() +"\n"+ teman.getNama() +"\n"+ teman.getKelas() +"\n"+ teman.getTlp() +"\n"+ teman.getEmail() +"\n"+ teman.getSosmed();
            System.out.println(tampil);
            vTampil.add(tampil);
        }
        Collections.sort(vTampil);
        return vTampil;
    }
}
