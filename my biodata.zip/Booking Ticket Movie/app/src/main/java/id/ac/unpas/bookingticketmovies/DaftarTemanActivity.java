package id.ac.unpas.bookingticketmovies;
//18/05/2019
//10116348
//yarisnuryana
//akbif08

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import id.ac.unpas.bookingticketmovies.R;

public class DaftarTemanActivity extends AppCompatActivity {
    TextView txt;
    ListView daftar;
    ArrayList<Teman> arrTeman;
    Helper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_tenab);
        daftar = (ListView) findViewById(R.id.lsView);
            Bundle bundle = getIntent().getExtras();
            String nim = bundle.getString("nim");
            String nama = bundle.getString("nama");
            String kelas = bundle.getString("kelas");
            String telepon = bundle.getString("telepon");
            String email = bundle.getString("email");
            String sosmed = bundle.getString("sosmed");
            Helper helper = new Helper();
            helper.simpanTeman(nim, nama, kelas, telepon, email, sosmed);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, helper.tampilTeman());
        daftar.setAdapter(adapter);

        txt = (TextView) findViewById(R.id.txtTambah);
        txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(id.ac.unpas.bookingticketmovies.DaftarTemanActivity.this, TambahTeman.class);
                startActivity(intent);
            }
        });
    }
}
