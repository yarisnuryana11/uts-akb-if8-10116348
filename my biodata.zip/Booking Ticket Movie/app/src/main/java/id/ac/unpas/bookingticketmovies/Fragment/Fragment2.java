package id.ac.unpas.bookingticketmovies.Fragment;
//19/05/2019
//10116348
//yarisnuryana
//akbif08

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import id.ac.unpas.bookingticketmovies.R;
import id.ac.unpas.bookingticketmovies.TambahTeman;
import id.ac.unpas.bookingticketmovies.Teman;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment2 extends Fragment {

    Button watch;
    ListView ls;
    AlertDialog.Builder dialog;
    String[] listTeman = {"1. Dhimas 0895378211515", "2. kaizer 08976545621", "3. yogi 0897654467", "4. zhafir 089384658343", "5. mangjang 08989827263"};

    public Fragment2() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_fragment2, container, false);
        ls = (ListView) view.findViewById(R.id.konList);
        ArrayAdapter adapter = new ArrayAdapter(getContext(), android.R.layout.simple_list_item_1, listTeman);
        ls.setAdapter(adapter);
        ls.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final CharSequence[] dialogitem = {"Edit", "Hapus"};
                dialog = new AlertDialog.Builder(getContext());
                dialog.setCancelable(true);
                dialog.setItems(dialogitem, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case 0:
                                Intent intent = new Intent(getContext(), TambahTeman.class);
                                startActivity(intent);
                                break;
                            case 1:
                            break;
                        }
                    }
                }).show();
                return false;
            }
        });
        return view;
    }

}
